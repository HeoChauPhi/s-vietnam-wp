﻿=== Location "Nav Menu" for ACF ===
Contributors: PSD2HTML
Tags: acf, menu, acf location
Requires at least: 5.0
Tested up to: 5.3.3
Current Supported  ACF Version: 5.3.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

ACF Add-On for displaying ACF fields in menu items edit box.

== Description ==
Use this addon to add advanced custom fields functionality to wordpress nav menu items.

== Installation ==
Copy \'acf-menu-location\' folder to your plugins directory.
